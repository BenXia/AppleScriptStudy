//
//  main.m
//  Lock Me Now
//
//  Created by Vitaly Parovishnik on 20.07.11.
//  Copyright 2010 IGR Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	@autoreleasepool {
		
		int retVal = NSApplicationMain(argc,  (const char **) argv);
		return retVal;
	}
}
