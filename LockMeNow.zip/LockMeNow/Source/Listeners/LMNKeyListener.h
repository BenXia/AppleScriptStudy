//
//  LMNKeyListener.h
//  LockMeNow
//
//  Created by Vitalii Parovishnyk on 1/27/15.
//
//

#import "LMNListenerManager.h"

@class PTHotKey;
@class SRRecorderControl;

@interface LMNKeyListener : LMNListenerManager

@end
