//
//  LMNLoginWindowsLock.h
//  LockMeNow
//
//  Created by Vitalii Parovishnyk on 1/22/15.
//
//

#import "LMNLockManager.h"

@interface LMNLoginWindowsLock : LMNLockManager

@end
