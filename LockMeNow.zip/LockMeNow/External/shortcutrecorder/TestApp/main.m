//
//  main.m
//  ShortcutRecorder
//
//  Copyright 2006-2007 Contributors. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
