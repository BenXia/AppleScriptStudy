shortcutrecorder
================

Unofficial repository of ShortcutRecorder, component of GureumKIM preference GUI.

