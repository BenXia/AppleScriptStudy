//
//  main.m
//  Example
//
//  Created by Vitalii Parovishnyk on 2/5/15.
//
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	return NSApplicationMain(argc, argv);
}
