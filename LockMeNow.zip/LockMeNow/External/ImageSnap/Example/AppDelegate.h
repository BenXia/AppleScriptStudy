//
//  AppDelegate.h
//  Example
//
//  Created by Vitalii Parovishnyk on 2/5/15.
//
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

