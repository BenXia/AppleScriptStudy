//
//  SUScheduledUpdateDriver.h
//  Sparkle
//
//  Created by Andy Matuschak on 5/6/08.
//  Copyright 2008 Andy Matuschak. All rights reserved.
//

#ifndef SUSCHEDULEDUPDATEDRIVER_H
#define SUSCHEDULEDUPDATEDRIVER_H

#import "SUUIBasedUpdateDriver.h"

@interface SUScheduledUpdateDriver : SUUIBasedUpdateDriver

@end

#endif
