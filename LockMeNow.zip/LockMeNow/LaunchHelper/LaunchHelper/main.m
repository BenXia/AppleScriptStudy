//
//  main.m
//  LaunchHelper
//
//  Created by Vitalii Parovishnyk on 2/4/15.
//  Copyright (c) 2015 IGR Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	return NSApplicationMain(argc, argv);
}
